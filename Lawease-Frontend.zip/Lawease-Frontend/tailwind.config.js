module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors:{
        pr: '#4BB070'
      }
    },
  },
  plugins: [],
}